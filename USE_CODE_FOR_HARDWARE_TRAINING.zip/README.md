# PyInsect Training Rig

Turns the photos from the turntable rig (`hardware/`) into a Pyinsect model. It's a web page that
runs **offline**, on the computer that does the training.

```
server.py              the Training Rig: shows the page, keeps the photos, runs the training
trainer.py             the training itself (like Train(MAIN).py: from scratch, photos squashed to 224x224)
web/                   the page (index.html, app.js, style.css, fonts/). No internet needed
inbox/                 put new photos here; they're added and trained on by themselves
settings.json          model type, rounds, batch size (made the first time it starts)
start-training-rig.bat double-click to start it on Windows
data/train/<insect>/   Training photo gallery     ┐ made by the Training Rig,
data/val/<insect>/     Validation photo gallery   │ not saved in git
models/<name>/         finished models            ┘
```

## Setting up the training PC (once, while it still has internet)

1. Install **Python 3** from python.org (tick "Add Python to PATH").
2. Install the AI tools. With an NVIDIA graphics card, get the command for your card from
   pytorch.org ("Get Started"), for example:
   `pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128`
   With no graphics card: `pip install torch torchvision`
3. `pip install onnx pillow` (onnx makes the `.onnx` file the website uses).
4. Copy this whole `training` folder to the PC (a USB stick is fine).

After that, no internet is needed.

## Using it

1. Double-click **start-training-rig.bat** (or run `python server.py`). The page opens at
   http://localhost:8200. Keep the black window open.
   - **From the laptop while it trains on the PC:** run `python server.py --lan` on the PC. The window
     shows an address like `http://192.168.1.20:8200`; open that on the laptop (same Wi-Fi or cable).
     Windows may ask to allow Python through the firewall: allow it on **Private** networks.
2. **Put photos in the inbox folder** (`training\inbox\`):
   - photos go in a folder named after the insect: `inbox\emerald_ash_borer\photo1.jpg`
   - the `.zip` files from the PyInsect Data Collector can go right in `inbox\`
   Once the copying has finished, the photos move into the galleries by themselves: the photos from the
   last fifth of the turn (288°–360°) go to **Validation** and the rest to **Training** (without angles,
   every 5th photo goes to Validation). Then **training starts by itself** (it needs photos of at least
   2 insects). Photos added while it trains wait in the inbox for the next run.
3. **The page** shows the **Training** and **Validation** photo galleries and the live **Loss** and
   **Accuracy** graphs, all on one screen. Tap photos to select them, then **Move** or **Delete**.
   Double-click a photo to see it big.
4. **Finished models** are saved in `training\models\<name>_<date>_<time>\`:
   - `<name>.pth`: the weights (the best round, measured on the Validation photos)
   - `<name>.onnx`: the same model for the website (input `input` 1×3×224×224, output `logits`)
   - `classes.json`: the insect names, in the model's output order
   - `info.json`: how it was trained, and the score of every round
   - `pyinsect-<name>.js`: a starting settings file for `assets/models/` (add the invasive list by hand)

## Settings

`training\settings.json` (made the first time the Training Rig starts; open it with Notepad):

| Setting | What it does | Normal value |
|---|---|---|
| `auto_train` | start training by itself when new photos arrive | `true` |
| `model_name` | the start of each model's name | `"pyinsect"` |
| `arch` | `efficientnet_b0` (light), `efficientnet_b1`, or `convnext_base` (needs a strong graphics card) | `"efficientnet_b0"` |
| `epochs` | how many rounds | `30` |
| `batch` | photos per step (lower it if the graphics card runs out of memory) | `16` |

## Good to know

- **From scratch takes many rounds and many photos.** Expect low scores for the first rounds. With a
  graphics card, 30–100 rounds is normal. On a CPU it's very slow.
- **Model types:** EfficientNet-B0 (light, like Pyinsect 2.x), EfficientNet-B1, ConvNeXt-Base (heavy,
  needs a strong graphics card). If the graphics card runs out of memory, lower the batch size.
- Photos can't be moved or deleted while training runs.
- The page and the server only talk to each other. Nothing is sent to the internet.
