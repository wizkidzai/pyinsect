// Keeps the Data Collector on the phone: open it once while the computer is connected, and after that it opens
// with nothing connected. When the computer is reachable the newest copy is used and saved again.
const CACHE = 'pyinsect-collector-5';
const FILES = ['./', 'index.html', 'style.css?v=6', 'jszip.min.js', 'app.js?v=12'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  e.respondWith((async () => {
    try {
      const res = await fetch(req);
      if (res.ok) (await caches.open(CACHE)).put(req, res.clone());
      return res;
    } catch (err) {
      const c = await caches.open(CACHE);
      return (await c.match(req)) || (await c.match(req, { ignoreSearch: true })) ||
             (req.mode === 'navigate' ? await c.match('index.html') : undefined) || Response.error();
    }
  })());
});
