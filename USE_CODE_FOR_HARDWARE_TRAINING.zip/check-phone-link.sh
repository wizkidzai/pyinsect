#!/bin/bash
# Linux: run on the fat PC while it is on the phone's hotspot. Shows why the phone can't find it.
ok(){ echo "  [OK]   $*"; }; bad(){ echo "  [FAIL] $*"; }
echo "Network addresses (the phone hotspot is the Wi-Fi one):"
ip -4 -o addr show | awk '{print $2, $4}' | grep -vE '^(lo|docker|br-|tailscale)' | while read card addr; do
  case "$card" in
    wl*) echo "  ${addr%/*}   <-- Wi-Fi ($card), joined to: $(nmcli -g GENERAL.CONNECTION device show $card 2>/dev/null)";;
    *)   echo "  ${addr%/*}   ($card)";;
  esac
done
ss -ltn 2>/dev/null | grep -q ":8100 " && ok "Training Rig is running (port 8100)" || bad "Training Rig is not running: python3 server.py"
ss -ltn 2>/dev/null | grep -q ":8090 " && ok "Phone door is running (port 8090)" || bad "Phone door is not running: python3 phone-door.py"
if command -v ufw >/dev/null; then
  st=$(ufw status 2>/dev/null | head -1); echo "  Firewall (ufw): ${st:-run 'sudo ufw status' to see}"
  echo "  To let the phone in:  sudo ufw allow 8090/tcp"
fi
command -v firewall-cmd >/dev/null && echo "  Firewall (firewalld): to let the phone in:  sudo firewall-cmd --add-port=8090/tcp   (add --permanent to keep it)"
echo
echo "On the phone's Chrome open  http://<one of the addresses above>:8090/api/whoami  - it should show {\"app\": \"pyinsect-rig\", ...}"
