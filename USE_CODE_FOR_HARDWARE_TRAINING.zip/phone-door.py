#!/usr/bin/env python3
"""The phone door: lets the PyInsect Data Collector on the phone find this computer and send photos to it over Wi-Fi.
Run it next to the Training Rig (server.py). Works on Windows, Mac and Linux, no extra installs.

  python phone-door.py                      asks which network the phone's hotspot is on
  python phone-door.py --network 192.168.246.0/24

Only the photo upload (/api/import) and the computer's name (/api/whoami) are passed on; nothing else.
Only phones on the chosen network are answered, so it is not open to the rest of the school/office network.
"""
import argparse, http.client, ipaddress, json, re, socket, subprocess, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ap = argparse.ArgumentParser()
ap.add_argument("--port", type=int, default=8090)
ap.add_argument("--rig-port", type=int, default=8100)
ap.add_argument("--network", action="append", help="phone network, e.g. 192.168.246.0/24 (can be given twice)")
args = ap.parse_args()

def my_addresses():
    found = set()
    try:
        for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            found.add(a[4][0])
    except OSError:
        pass
    try:   # Linux: read every address straight from the network cards (hostname lookups often only give 127.0.1.1)
        out = subprocess.run(["ip", "-4", "-o", "addr", "show"], capture_output=True, text=True, timeout=3).stdout
        found.update(re.findall(r"inet (\d+\.\d+\.\d+\.\d+)/", out))
    except (OSError, subprocess.SubprocessError):
        pass
    for probe in ("192.168.43.1", "192.168.1.1", "10.0.0.1", "172.16.0.1"):   # the address this PC would use to reach it
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect((probe, 9)); found.add(s.getsockname()[0]); s.close()
        except OSError:
            pass
    skip = ("127.", "172.17.", "172.18.", "172.19.", "100.")   # loopback, Docker, Tailscale
    return sorted(ip for ip in found if ipaddress.ip_address(ip).is_private and not ip.startswith(skip))

def where(ip):
    """Which network card (and Wi-Fi name, if it is Wi-Fi) an address belongs to. Linux only; blank elsewhere."""
    try:
        out = subprocess.run(["ip", "-4", "-o", "addr", "show"], capture_output=True, text=True, timeout=3).stdout
        card = next((l.split()[1] for l in out.splitlines() if f"inet {ip}/" in l), "")
        if not card:
            return ""
        wifi = card.startswith(("wl", "wlan"))
        name = ""
        if wifi:
            name = subprocess.run(["nmcli", "-g", "GENERAL.CONNECTION", "device", "show", card], capture_output=True, text=True, timeout=3).stdout.strip()
        return f"({card}{': Wi-Fi ' + name if wifi else ''})" if not wifi else f"({card}: Wi-Fi {name or 'network'})"
    except (OSError, subprocess.SubprocessError):
        return ""

nets = [ipaddress.ip_network(n, strict=False) for n in (args.network or [])]
if not nets:
    mine = my_addresses()
    if not mine:
        raise SystemExit("No private network address found. Join the phone's hotspot first, then run this again.")
    print("This computer's addresses:")
    for i, ip in enumerate(mine, 1):
        print(f"  {i}. {ip}   {where(ip)}")
    wifi = [i for i, ip in enumerate(mine, 1) if "Wi-Fi" in where(ip)]
    dflt = str(wifi[0]) if len(wifi) == 1 else "1"
    pick = input(f"Which one is on the phone's hotspot? It is the Wi-Fi one. [{dflt}] ").strip() or dflt
    nets = [ipaddress.ip_network(mine[int(pick) - 1] + "/24", strict=False)]

seen = set()
def note(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def reply(self, code, data=b"", ctype="application/json"):
        self.send_response(code)
        self.send_header("Access-Control-Allow-Origin", "*")
        # NEW: The phone sends the zip as "application/zip", so Chrome first asks (OPTIONS) whether that's allowed.
        # Without these answers Chrome blocks the upload: the door then only says "Phone ... is talking".
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data)
    def handle_any(self):
        ip = ipaddress.ip_address(self.client_address[0])
        if not any(ip in n for n in nets):
            if ip not in seen:
                seen.add(ip); note(f"REFUSED {ip}: it is not on {', '.join(map(str, nets))}. Run this again and pick the right network, or use --network.")
            return self.reply(403)
        if ip not in seen:
            seen.add(ip); note(f"Phone {ip} is talking to this computer.")
        path = self.path.split("?")[0]
        if path == "/api/whoami" and self.command in ("GET", "OPTIONS"):
            return self.reply(200, json.dumps({"app": "pyinsect-rig", "name": socket.gethostname()}).encode()) if self.command == "GET" else self.reply(204)
        if path != "/api/import" or self.command not in ("POST", "OPTIONS"):
            return self.reply(404)
        if self.command == "OPTIONS":
            # NEW: Chrome's "may I send a zip?" check: the door says yes itself, so the upload works even if an
            # older server.py (one that doesn't answer OPTIONS) is the one running on the rig port.
            return self.reply(204)
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n) if n else None
        c = http.client.HTTPConnection("127.0.0.1", args.rig_port, timeout=600)
        try:
            c.request(self.command, self.path, body=body, headers={"Content-Type": self.headers.get("Content-Type", "application/octet-stream")} if body else {})
            r = c.getresponse(); data = r.read()
        except OSError:
            return self.reply(502, b'{"error": "The Training Rig is not running on this computer (start server.py)."}')
        if self.command == "POST":
            note(f"Upload from {ip}: {len(body or b'') // 1024} KB, the Training Rig on port {args.rig_port} answered {r.status}: {data[:160].decode('utf-8', 'replace')}")
        self.reply(r.status, data, r.getheader("Content-Type", "application/json"))
    do_GET = do_POST = do_OPTIONS = handle_any
    def log_message(self, *a): pass

for _ip in my_addresses():
    if any(ipaddress.ip_address(_ip) in n for n in nets):
        print(f"On the phone you can also type this address: {_ip}:{args.port}")
print(f"Phone door ready on port {args.port} for phones on {', '.join(map(str, nets))}. Leave this window open.")
print('If the phone finds nothing, nothing will be printed below. Then check: the Windows firewall (allow Python on Private networks) and that the phone and this PC are on the same hotspot.')
try:
    ThreadingHTTPServer(("0.0.0.0", args.port), H).serve_forever()
except KeyboardInterrupt:
    print("Stopped.")
