"""Trains a Pyinsect model from scratch, like Train(MAIN).py, in a background thread.

The web page (server.py) starts it, asks for its progress every second, and can stop it.
Photos come from data/train/<insect>/ and data/val/<insect>/. The finished model goes to
models/<name>/: <name>.pth (weights), <name>.onnx (for the website), classes.json and info.json.
"""
import json
import os
import threading
import time
import traceback

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp")

# Same model types as Train(MAIN).py
ARCHS = {
    "efficientnet_b0": "EfficientNet-B0 (light and fast)",
    "efficientnet_b1": "EfficientNet-B1 (balanced)",
    "convnext_base": "ConvNeXt-Base (heavy, needs a strong graphics card)",
}


def list_photos(split_dir):
    """{insect: [file paths]} for one gallery folder, skipping empty insects."""
    out = {}
    if not os.path.isdir(split_dir):
        return out
    for cls in sorted(os.listdir(split_dir)):
        d = os.path.join(split_dir, cls)
        if not os.path.isdir(d):
            continue
        files = sorted(f for f in os.listdir(d) if f.lower().endswith(IMAGE_EXT))
        if files:
            out[cls] = [os.path.join(d, f) for f in files]
    return out


def build_model(arch, num_classes):
    """The model skeleton with no pretrained weights (trained from scratch), like Train(MAIN).py."""
    import torch.nn as nn
    from torchvision import models
    if arch == "efficientnet_b0":
        m = models.efficientnet_b0(weights=None)
        m.classifier = nn.Sequential(nn.Dropout(p=0.2, inplace=True), nn.Linear(m.classifier[1].in_features, num_classes))
    elif arch == "efficientnet_b1":
        m = models.efficientnet_b1(weights=None)
        m.classifier = nn.Sequential(nn.Dropout(p=0.2, inplace=True), nn.Linear(m.classifier[1].in_features, num_classes))
    elif arch == "convnext_base":
        m = models.convnext_base(weights=None)
        m.classifier[2] = nn.Linear(m.classifier[2].in_features, num_classes)
    else:
        raise ValueError(f"Unknown model type: {arch}")
    return m


def pick_device():
    import torch
    if torch.cuda.is_available():
        return torch.device("cuda"), torch.cuda.get_device_name(0)
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return torch.device("mps"), "Apple GPU"
    return torch.device("cpu"), "CPU (no graphics card found, so training is slow)"


class Trainer:
    def __init__(self, data_dir, models_dir):
        self.data_dir, self.models_dir = data_dir, models_dir
        self.lock = threading.Lock()
        self.stop_flag = threading.Event()
        self.thread = None
        self.state = {"status": "idle", "message": "Ready.", "history": [], "log": []}

    # ---------- for the web page ----------
    def running(self):
        return self.thread is not None and self.thread.is_alive()

    def status(self):
        with self.lock:
            return json.loads(json.dumps(self.state))

    def _set(self, **kw):
        with self.lock:
            self.state.update(kw)

    def _log(self, text):
        line = time.strftime("%H:%M:%S ") + text
        print("[training]", line, flush=True)
        with self.lock:
            self.state["log"] = (self.state["log"] + [line])[-200:]

    def start(self, name, arch, epochs, batch_size):
        if self.running():
            raise RuntimeError("Training is already running.")
        if arch not in ARCHS:
            raise ValueError("Pick a model type.")
        self.stop_flag.clear()
        self.state = {"status": "starting", "message": "Getting ready…", "name": name, "arch": arch,
                      "epochs": epochs, "epoch": 0, "batch": 0, "batches": 0, "history": [], "log": [],
                      "started": time.time()}
        self.thread = threading.Thread(target=self._run, args=(name, arch, epochs, batch_size), daemon=True)
        self.thread.start()

    def stop(self):
        if self.running():
            self.stop_flag.set()
            self._set(message="Stopping after this batch…")

    # ---------- the training itself ----------
    def _run(self, name, arch, epochs, batch_size):
        try:
            self._train(name, arch, epochs, batch_size)
        except Exception as e:  # show the problem on the page instead of crashing the server
            traceback.print_exc()
            self._log("Error: " + str(e))
            self._set(status="error", message="Something went wrong: " + str(e))

    def _train(self, name, arch, epochs, batch_size):
        import torch
        import torch.nn as nn
        import torch.optim as optim
        from PIL import Image
        from torch.utils.data import DataLoader, Dataset
        from torchvision import transforms

        train = list_photos(os.path.join(self.data_dir, "train"))
        val = list_photos(os.path.join(self.data_dir, "val"))
        classes = sorted(train)
        if len(classes) < 2:
            raise ValueError("The Training gallery needs photos of at least 2 different insects.")
        idx = {c: i for i, c in enumerate(classes)}
        train_items = [(p, idx[c]) for c in classes for p in train[c]]
        val_items = [(p, idx[c]) for c, ps in val.items() if c in idx for p in ps]
        missing = [c for c in classes if c not in val]
        if not val_items:
            raise ValueError("The Validation gallery is empty. Add some photos to it first.")
        if missing:
            self._log("No validation photos for: " + ", ".join(missing) + " (their accuracy isn't checked)")
        skipped = sorted(c for c in val if c not in idx)
        if skipped:
            self._log("Not in the Training gallery, so left out of validation: " + ", ".join(skipped))

        # Same photo preparation as Train(MAIN).py: squash to 224x224, ImageNet colours
        norm = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        train_tf = transforms.Compose([transforms.Resize((224, 224)), transforms.RandomHorizontalFlip(),
                                       transforms.RandomRotation(15), transforms.ToTensor(), norm])
        val_tf = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor(), norm])

        class Photos(Dataset):
            def __init__(self, items, tf):
                self.items, self.tf = items, tf

            def __len__(self):
                return len(self.items)

            def __getitem__(self, i):
                path, label = self.items[i]
                with Image.open(path) as im:
                    return self.tf(im.convert("RGB")), label

        train_loader = DataLoader(Photos(train_items, train_tf), batch_size=batch_size, shuffle=True, num_workers=0)
        val_loader = DataLoader(Photos(val_items, val_tf), batch_size=batch_size, shuffle=False, num_workers=0)

        device, device_name = pick_device()
        if device.type == "cuda":
            torch.backends.cudnn.benchmark = True
        self._set(device=device_name, classes=classes, train_count=len(train_items), val_count=len(val_items),
                  batches=len(train_loader))
        self._log(f"{len(classes)} insects, {len(train_items)} training photos, {len(val_items)} validation photos")
        self._log(f"Model: {ARCHS[arch]}, from scratch, on {device_name}")

        model = build_model(arch, len(classes)).to(device)
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=0.01)  # same as Train(MAIN).py

        out_dir = os.path.join(self.models_dir, name)
        os.makedirs(out_dir, exist_ok=True)
        pth = os.path.join(out_dir, name + ".pth")
        best_acc, best_epoch = -1.0, 0
        self._set(status="training", message="Training…")

        for epoch in range(1, epochs + 1):
            if self.stop_flag.is_set():
                break
            self._set(epoch=epoch, batch=0, message=f"Round {epoch} of {epochs}")
            model.train()
            loss_sum, correct, total = 0.0, 0, 0
            for b, (images, labels) in enumerate(train_loader, 1):
                if self.stop_flag.is_set():
                    break
                images, labels = images.to(device), labels.to(device)
                optimizer.zero_grad()
                outputs = model(images)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                loss_sum += loss.item() * images.size(0)
                correct += (outputs.argmax(1) == labels).sum().item()
                total += labels.size(0)
                self._set(batch=b, live_loss=loss_sum / total, live_acc=100 * correct / total)
            if self.stop_flag.is_set() or not total:
                break

            model.eval()
            v_loss, v_correct, v_total = 0.0, 0, 0
            self._set(message=f"Round {epoch} of {epochs}: checking the Validation photos")
            with torch.no_grad():
                for images, labels in val_loader:
                    images, labels = images.to(device), labels.to(device)
                    outputs = model(images)
                    v_loss += criterion(outputs, labels).item() * images.size(0)
                    v_correct += (outputs.argmax(1) == labels).sum().item()
                    v_total += labels.size(0)
            row = {"epoch": epoch, "train_loss": loss_sum / total, "train_acc": 100 * correct / total,
                   "val_loss": v_loss / v_total, "val_acc": 100 * v_correct / v_total}
            with self.lock:
                self.state["history"].append(row)
            self._log(f"Round {epoch}: train loss {row['train_loss']:.4f}, train {row['train_acc']:.1f}% | "
                      f"val loss {row['val_loss']:.4f}, val {row['val_acc']:.1f}%")
            if row["val_acc"] > best_acc:  # keep the best round, not just the last one
                best_acc, best_epoch = row["val_acc"], epoch
                torch.save(model.state_dict(), pth)
                self._set(best_acc=best_acc, best_epoch=best_epoch)

        stopped = self.stop_flag.is_set()
        if best_epoch == 0:
            self._set(status="stopped", message="Stopped before the first round finished, so no model was saved.")
            self._log("Stopped. No model saved.")
            return

        # Save the extra files for the best round
        self._set(status="exporting", message="Saving the model files…")
        model.load_state_dict(torch.load(pth, map_location=device))
        model.eval()
        history = self.status()["history"]
        info = {"name": name, "arch": arch, "classes": classes, "resize": "squash", "size": 224,
                "mean": [0.485, 0.456, 0.406], "std": [0.229, 0.224, 0.225], "trained_from": "scratch",
                "epochs_done": len(history), "epochs_planned": epochs, "best_epoch": best_epoch,
                "best_val_acc": best_acc, "train_photos": len(train_items), "val_photos": len(val_items),
                "device": device_name, "history": history, "finished": time.strftime("%Y-%m-%d %H:%M:%S")}
        with open(os.path.join(out_dir, "classes.json"), "w", encoding="utf-8") as f:
            json.dump(classes, f, indent=1)
        with open(os.path.join(out_dir, "info.json"), "w", encoding="utf-8") as f:
            json.dump(info, f, indent=1)
        onnx_ok = self._export_onnx(model.cpu(), os.path.join(out_dir, name + ".onnx"))
        if onnx_ok:
            self._write_site_config(name, classes, os.path.join(out_dir, name + ".onnx"), out_dir)
        word = "Stopped early" if stopped else "Done"
        self._set(status="done", message=f"{word}! Best round: {best_epoch} ({best_acc:.1f}% on the Validation photos).")
        self._log(f"{word}. Saved models/{name}/ (best round {best_epoch}, {best_acc:.1f}%)")

    def _export_onnx(self, model, path):
        """The .onnx file the website runs (input 'input' 1x3x224x224, output 'logits')."""
        import torch
        dummy = torch.zeros(1, 3, 224, 224)
        for kw in ({"dynamo": False}, {}):  # the classic exporter makes one simple file; fall back to the new one
            try:
                torch.onnx.export(model, dummy, path, input_names=["input"], output_names=["logits"],
                                  opset_version=17, **kw)
                self._log(f"Saved {os.path.basename(path)} ({os.path.getsize(path) // 1024 // 1024} MB)")
                return True
            except Exception as e:  # noqa: BLE001
                err = e
        self._log(f"Couldn't make the .onnx file ({err}). The .pth file is saved. Is the 'onnx' package installed?")
        return False

    def _write_site_config(self, name, classes, onnx_path, out_dir):
        """A starting model settings file for the website (assets/models/). Add the invasive list by hand."""
        cfg = (
            f"// Made by the Training Rig on {time.strftime('%Y-%m-%d')}. Copy {name}.onnx to model/ and this file to\n"
            f"// assets/models/, then fill in `invasive` (and keep it in sync with relay/worker.js).\n"
            "window.PYINSECT_MODEL = {\n"
            f"  name: {json.dumps(name)},\n"
            f"  url: new URL(\"../../model/{name}.onnx\", document.currentScript.src).href,\n"
            f"  size: {os.path.getsize(onnx_path)},\n"
            "  resize: \"squash\",   // trained with Resize((224, 224)), like Train(MAIN).py\n"
            "  scientific: false,\n"
            f"  classes: {json.dumps(classes)},\n"
            "  invasive: [],\n"
            "};\n")
        with open(os.path.join(out_dir, f"pyinsect-{name}.js"), "w", encoding="utf-8") as f:
            f.write(cfg)
