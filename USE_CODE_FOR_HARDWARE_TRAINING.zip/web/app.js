// PyInsect Training Rig page: the two photo galleries and the training graphs, on one screen.
// New photos go in the training\inbox\<insect>\ folder; server.py adds them and starts training by itself.
// Talks only to server.py (no internet needed).
"use strict";
const $ = id => document.getElementById(id);
const SHOW = 60;   // photos shown per insect before "Show all"
let photos = { train: {}, val: {} };
const selected = { train: new Set(), val: new Set() };   // "insect/file"
const showAll = new Set();                               // "split/insect"
let status = { status: "idle", history: [] }, galleryKey = "";

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}
async function api(path, body) {
  const res = await fetch(path, body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
  return data;
}
const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
const training = () => ["starting", "training", "exporting"].includes(status.status);

// ---------- galleries ----------
async function loadGallery() {
  let g;
  try { g = await api("/api/gallery"); } catch { return; }
  const key = JSON.stringify(g);
  if (key === galleryKey) return;   // nothing changed: don't redraw (keeps the scroll place)
  galleryKey = key; photos = g;
  for (const split of ["train", "val"]) {
    for (const k of [...selected[split]]) {   // forget photos that are gone
      const [cls, file] = k.split("/");
      if (!(photos[split][cls] || []).includes(file)) selected[split].delete(k);
    }
    renderGallery(split);
  }
}

function renderGallery(split) {
  const body = $(`gal-${split}`), data = photos[split], insects = Object.keys(data);
  const top = body.scrollTop;
  const count = insects.reduce((n, c) => n + data[c].length, 0);
  $(`count-${split}`).textContent = `${plural(count, "photo")} · ${plural(insects.length, "insect")}`;
  body.innerHTML = "";
  if (!insects.length) {
    const p = el("p", "empty", "No photos yet. Put photos in ");
    p.append(el("code", null, "training\\inbox\\<insect name>\\"), " and they show up here.");
    body.append(p);
  }
  for (const cls of insects) {
    const files = data[cls], box = el("div", "insect"), head = el("div", "insect-head");
    head.append(el("strong", null, `${cls} (${files.length})`));
    const del = el("button", "btn danger", "Remove insect"); del.type = "button";
    del.title = "Delete all photos of this insect from BOTH galleries";
    del.onclick = async () => {
      if (!confirm(`Delete ALL photos of "${cls}" from both galleries? This can't be undone.`)) return;
      try { await api("/api/insect/delete", { cls }); } catch (e) { alert(e.message); }
      loadGallery();
    };
    head.append(del);
    const grid = el("div", "thumbs"), all = showAll.has(`${split}/${cls}`);
    for (const file of all ? files : files.slice(0, SHOW)) {
      const k = `${cls}/${file}`, b = el("button", "thumb" + (selected[split].has(k) ? " sel" : ""));
      b.type = "button"; b.title = `${file}\nTap to select. Double-click to see it big.`;
      const img = el("img"); img.loading = "lazy"; img.alt = file;
      img.src = `/thumb/${split}/${encodeURIComponent(cls)}/${encodeURIComponent(file)}`;
      b.append(img);
      b.onclick = () => { selected[split].has(k) ? selected[split].delete(k) : selected[split].add(k); b.classList.toggle("sel"); updateTools(split); };
      b.ondblclick = () => openViewer(split, cls, file);
      grid.append(b);
    }
    box.append(head, grid);
    if (files.length > SHOW) {
      const more = el("button", "btn more", all ? "Show fewer" : `Show all ${files.length}`); more.type = "button";
      more.onclick = () => { all ? showAll.delete(`${split}/${cls}`) : showAll.add(`${split}/${cls}`); renderGallery(split); };
      box.append(more);
    }
    body.append(box);
  }
  body.scrollTop = top;
  updateTools(split);
}

function updateTools(split) {
  const tools = document.querySelector(`.gallery[data-split="${split}"] .gal-tools`), n = selected[split].size;
  tools.hidden = !n;
  tools.querySelector(".sel-count").textContent = `${plural(n, "photo")} selected`;
}

document.querySelectorAll(".gallery").forEach(g => {
  const split = g.dataset.split;
  g.querySelector(".gal-tools").addEventListener("click", async e => {
    const act = e.target.dataset?.act;
    if (!act) return;
    if (act === "clear") { selected[split].clear(); renderGallery(split); return; }
    const list = [...selected[split]].map(k => { const [cls, file] = k.split("/"); return { split, cls, file }; });
    if (act === "delete" && !confirm(`Delete ${plural(list.length, "photo")}? This can't be undone.`)) return;
    try { await api(act === "move" ? "/api/photos/move" : "/api/photos/delete", { photos: list }); }
    catch (err) { alert(err.message); }
    selected[split].clear();
    galleryKey = "";
    loadGallery();
  });
});

function openViewer(split, cls, file) {
  $("viewerImg").src = `/photo/${split}/${encodeURIComponent(cls)}/${encodeURIComponent(file)}`;
  $("viewerCap").textContent = `${split === "train" ? "Training" : "Validation"} · ${cls} · ${file}`;
  $("viewer").hidden = false;
  $("viewerClose").focus();
}
$("viewerClose").onclick = () => { $("viewer").hidden = true; $("viewerImg").src = ""; };
document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("viewer").hidden) $("viewerClose").click(); });

// ---------- status (training starts by itself when new photos arrive) ----------
async function poll() {
  try { status = await api("/api/status"); } catch {
    $("badge").textContent = "Offline"; $("badge").className = "pill error";
    $("barText").textContent = "Can't reach the Training Rig. Is server.py still running?";
    clearTimeout(poll.t); poll.t = setTimeout(poll, 3000); return;
  }
  const busy = training();
  const badge = $("badge");
  badge.textContent = { idle: "Ready", starting: "Starting…", training: "Training", exporting: "Saving…", done: "Done", stopped: "Stopped", error: "Problem" }[status.status] || status.status;
  badge.className = "pill" + (busy ? " busy" : status.status === "error" ? " error" : "");

  let text;
  if (status.status === "training") {
    const pct = status.batches ? Math.round((status.batch / status.batches) * 100) : 0;
    text = `${status.name} · round ${status.epoch} of ${status.epochs} (${pct}%)` + (status.best_acc != null ? ` · best so far ${status.best_acc.toFixed(1)}%` : "");
  } else if (busy) text = status.message;
  else if (status.inbox_note && status.status === "idle") text = status.inbox_note;
  else if (["done", "stopped", "error"].includes(status.status)) text = `${status.message}${status.status === "done" ? ` Saved in training\\models\\${status.name}\\.` : ""}`;
  else text = "Put photos in training\\inbox\\<insect name>\\ and training starts by itself.";
  if (busy && status.inbox_waiting) text += ` · ${plural(status.inbox_waiting, "new photo")} waiting for the next run`;
  $("barText").textContent = text;
  $("barText").title = text;
  $("stopBtn").hidden = !["starting", "training"].includes(status.status);

  drawCharts(status.history || []);
  loadGallery();
  clearTimeout(poll.t);
  poll.t = setTimeout(poll, busy ? 1000 : 3000);
}

$("stopBtn").onclick = async () => {
  const b = $("stopBtn");
  if (!confirm("Stop training? If at least one round has finished, the best round is saved as a model.")) return;
  b.disabled = true; b.textContent = "Stopping…";
  try { await api("/api/stop", {}); } catch (err) { alert(err.message); }
  b.disabled = false; b.textContent = "Stop training";
  poll();
};

// ---------- graphs (drawn by hand, so no chart library is needed offline) ----------
function drawCharts(history) {
  chart($("lossChart"), history, [["train_loss", "--accent"], ["val_loss", "--val"]], null);
  chart($("accChart"), history, [["train_acc", "--accent"], ["val_acc", "--val"]], 100);
}
function chart(canvas, rows, lines, fixedMax) {
  const css = getComputedStyle(document.documentElement), dpr = window.devicePixelRatio || 1;
  const W = canvas.clientWidth, H = canvas.clientHeight;
  if (!W || !H) return;
  canvas.width = W * dpr; canvas.height = H * dpr;
  const g = canvas.getContext("2d");
  g.scale(dpr, dpr);
  const L = 44, R = 14, T = 14, B = 26, w = W - L - R, h = H - T - B;
  const muted = css.getPropertyValue("--muted").trim(), grid = css.getPropertyValue("--grid").trim();
  g.font = "12px 'IBM Plex Sans', system-ui, sans-serif"; g.fillStyle = muted;
  if (!rows.length) { g.textAlign = "center"; g.fillText("The graph appears after the first round.", W / 2, H / 2); return; }
  const max = fixedMax ?? Math.max(...rows.flatMap(r => lines.map(([k]) => r[k])), 0.01) * 1.1;
  const n = rows.length, x = i => L + (n === 1 ? w / 2 : (i / (n - 1)) * w), y = v => T + h - (v / max) * h;
  g.strokeStyle = grid; g.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const v = (max / 4) * i, yy = y(v);
    g.beginPath(); g.moveTo(L, yy); g.lineTo(L + w, yy); g.stroke();
    g.fillText(fixedMax ? String(Math.round(v)) : v.toFixed(2), 4, yy + 4);
  }
  const step = Math.max(1, Math.ceil(n / 10));
  g.textAlign = "center";
  rows.forEach((r, i) => { if (i % step === 0 || i === n - 1) g.fillText(String(r.epoch), x(i), H - 7); });
  for (const [key, color] of lines) {
    g.strokeStyle = g.fillStyle = css.getPropertyValue(color).trim(); g.lineWidth = 2.5; g.lineJoin = "round";
    g.beginPath();
    rows.forEach((r, i) => (i ? g.lineTo(x(i), y(r[key])) : g.moveTo(x(i), y(r[key]))));
    g.stroke();
    rows.forEach((r, i) => { g.beginPath(); g.arc(x(i), y(r[key]), 3, 0, 7); g.fill(); });
  }
}
window.addEventListener("resize", () => drawCharts(status.history || []));

poll();
