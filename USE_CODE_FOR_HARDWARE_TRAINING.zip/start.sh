#!/bin/bash
# Stops the old (stuck) Training Rig and phone door, then starts fresh ones.
#   ./restart.sh                     the phone door uses the Wi-Fi network (the phone's hotspot)
#   ./restart.sh 192.168.246.0/24    or this network
cd "$(dirname "$0")" || exit 1
PY=python3; [ -x .venv/bin/python ] && PY=.venv/bin/python

# 1. Stop whatever is holding the Training Rig's ports (8100) and the phone door's (8090)
for port in 8100 8090; do
  for pid in $(ss -ltnpH "sport = :$port" 2>/dev/null | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u); do
    echo "Stopping old copy on port $port (process $pid)"
    kill "$pid" 2>/dev/null
  done
done
pkill -f "phone-door.py" 2>/dev/null
for _ in 1 2 3 4 5 6 7 8 9 10; do
  ss -ltnH "sport = :8100 or sport = :8090" 2>/dev/null | grep -q . || break
  sleep 0.5
done
if ss -ltnH "sport = :8100 or sport = :8090" 2>/dev/null | grep -q .; then
  echo "Still stuck, forcing it to stop…"
  for port in 8100 8090; do
    for pid in $(ss -ltnpH "sport = :$port" 2>/dev/null | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u); do kill -9 "$pid" 2>/dev/null; done
  done
  sleep 1
fi

# 2. Start the Training Rig in the background
"$PY" server.py > rig.log 2>&1 &
RIG=$!
trap 'kill $RIG 2>/dev/null; echo; echo "Stopped."; exit 0' INT TERM
sleep 2
kill -0 $RIG 2>/dev/null || { cat rig.log; echo "The Training Rig didn't start (see above)."; exit 1; }
echo "Training Rig running: http://localhost:8100"

# 3. Start the phone door on the phone's hotspot network
NET="$1"
if [ -z "$NET" ]; then
  WIFI=$(ip -4 -o addr show | awk '$2 ~ /^wl/ {print $4; exit}')   # Wi-Fi cards are called wl…
  [ -n "$WIFI" ] && NET=$("$PY" -c "import ipaddress, sys; print(ipaddress.ip_interface(sys.argv[1]).network)" "$WIFI")
fi
if [ -n "$NET" ]; then
  "$PY" phone-door.py --network "$NET"
else
  "$PY" phone-door.py   # no Wi-Fi found: it asks which network
fi
kill $RIG 2>/dev/null

