#!/bin/bash
cd "$(dirname "$0")"

# Force-kill any running python instances of these scripts
pkill -9 -f "python.*server\.py"
pkill -9 -f "python.*phone-door\.py"
sleep 1

trap 'pkill -9 -f "python.*server\.py"; pkill -9 -f "python.*phone-door\.py"' EXIT

python3 server.py &
sleep 2
python3 phone-door.py
