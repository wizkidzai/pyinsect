"""PyInsect Training Rig: an offline web app for training a model from the rig's photos.

Run it on the training PC:   python server.py            (then open http://localhost:8200)
Use it from another computer on the same network:   python server.py --lan
Put photos in inbox/<insect name>/ (or drop the rig's .zip files in inbox/): they move into the
galleries and training starts by itself. Settings (model type, rounds...) are in settings.json.
Needs Python 3 with torch, torchvision and pillow (and onnx for the .onnx file). No internet needed.
"""
import argparse
import webbrowser
import csv
import io
import json
import mimetypes
import os
import re
import shutil
import socket
import sys
import tempfile
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlparse

from trainer import ARCHS, IMAGE_EXT, Trainer, list_photos
print("PRESS ENTER FOR INPUT")

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")          # data/train/<insect>/, data/val/<insect>/
MODELS = os.path.join(ROOT, "models")      # models/<name>/
THUMBS = os.path.join(ROOT, ".thumbs")     # small copies for the galleries
WEB = os.path.join(ROOT, "web")
# The PyInsect Data Collector (phone web app), served at /collect/ so phone and computer share one address
_here = os.path.join(ROOT, "collector")   # the Data Collector page, copied next to server.py when the folder is moved
COLLECT = os.environ.get("PYINSECT_COLLECTOR") or (_here if os.path.isdir(_here) else "/home/aariv/workspace/pyinsect-software/pyinsect/hardware")
INBOX = os.path.join(ROOT, "inbox")        # put new photos here: inbox/<insect>/... or inbox/<file>.zip
SETTINGS = os.path.join(ROOT, "settings.json")
DEFAULT_SETTINGS = {
    "auto_train": True,               # start training by itself when new photos arrive
    "model_name": "pyinsect",         # models are saved as <model_name>_<date>_<time>
    "arch": "efficientnet_b0",        # efficientnet_b0, efficientnet_b1 or convnext_base
    "epochs": 30,                     # rounds
    "batch": 16,                      # lower it if the graphics card runs out of memory
}
SPLITS = ("train", "val")
VAL_FROM_DEG = 288   # Auto split: photos from the last fifth of the turn (288-360°) go to Validation

trainer = Trainer(DATA, MODELS)


def safe_name(text):
    """Folder-safe insect or model name: lower case, letters, numbers and _ only."""
    return re.sub(r"[^a-z0-9_]+", "_", (text or "").strip().lower()).strip("_")[:60]


def safe_file(text):
    base = os.path.basename((text or "").replace("\\", "/"))
    base = re.sub(r"[^A-Za-z0-9_.-]+", "_", base)
    return base if base.lower().endswith(IMAGE_EXT) and not base.startswith(".") else ""


def photo_path(split, cls, file):
    if split not in SPLITS or safe_name(cls) != cls or safe_file(file) != file:
        raise ValueError("bad photo")
    return os.path.join(DATA, split, cls, file)


def free_path(path):
    """path, or path with _2, _3… when a photo with that name is already there."""
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(path):
        path = f"{stem}_{n}{ext}"
        n += 1
    return path


def angle_of(filename, labels):
    """The turntable angle of a photo, from labels.csv or a name like bug_012_043p2deg_dim.jpg."""
    if filename in labels:
        return labels[filename]
    m = re.search(r"_(\d+)p(\d+)deg", filename)
    return float(f"{m.group(1)}.{m.group(2)}") if m else None


def import_zip(zip_path, split, name_hint, stem=None):
    """Adds the photos in a zip (from the hardware app, or any zip of photos) to the galleries."""
    added = {"train": 0, "val": 0}
    insects = set()
    with zipfile.ZipFile(zip_path) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        # labels.csv from the hardware app: file, insect, angle, lighting, time
        labels, insect_of = {}, {}
        for n in names:
            if os.path.basename(n).lower() == "labels.csv":
                text = z.read(n).decode("utf-8", "replace")
                for row in csv.DictReader(io.StringIO(text)):
                    f = os.path.basename(row.get("file") or "")
                    try:
                        labels[f] = float(row.get("angle") or row.get("angle_deg") or "")
                    except ValueError:
                        pass
                    if row.get("insect"):
                        insect_of[f] = row["insect"]
        photos = [n for n in names if n.lower().endswith(IMAGE_EXT) and "__MACOSX" not in n]
        stem = stem or os.path.splitext(os.path.basename(zip_path))[0]
        # If the turntable never turned (every angle the same), angles can't pick the Validation photos
        angles = {angle_of(os.path.basename(n), labels) for n in photos}
        spun = len(angles) > 1 and None not in angles
        for i, n in enumerate(sorted(photos)):
            f = os.path.basename(n)
            parts = n.replace("\\", "/").split("/")
            # insect name: typed name > labels.csv > folder in the zip > zip file name
            cls = safe_name(name_hint) or safe_name(insect_of.get(f, "")) or (safe_name(parts[-2]) if len(parts) > 1 else "") or safe_name(stem)
            if not cls:
                continue
            if split == "auto":
                a = angle_of(f, labels) if spun else None
                where = ("val" if a >= VAL_FROM_DEG else "train") if a is not None else ("val" if i % 5 == 4 else "train")
            else:
                where = split
            dest = os.path.join(DATA, where, cls)
            os.makedirs(dest, exist_ok=True)
            out = free_path(os.path.join(dest, safe_file(f) or f"photo_{i:04d}.jpg"))
            with z.open(n) as src, open(out, "wb") as dst:
                shutil.copyfileobj(src, dst)
            added[where] += 1
            insects.add(cls)
    return added, sorted(insects)


def gallery():
    out = {}
    for split in SPLITS:
        out[split] = {cls: [os.path.basename(p) for p in ps] for cls, ps in list_photos(os.path.join(DATA, split)).items()}
    return out


def load_settings():
    """settings.json (made with the defaults the first time). Edit it with Notepad."""
    st = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS, encoding="utf-8") as f:
            st.update(json.load(f))
    except FileNotFoundError:
        with open(SETTINGS, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_SETTINGS, f, indent=2)
    except ValueError:
        print("settings.json has a typing mistake, so the default settings are used.")
    return st


def inbox_files():
    """Every photo and zip in the inbox, with its size (to see when copying has finished)."""
    out = {}
    for dirpath, _, files in os.walk(INBOX):
        for f in files:
            if f.lower().endswith(IMAGE_EXT + (".zip",)) and not f.startswith("."):
                p = os.path.join(dirpath, f)
                try:
                    out[p] = os.path.getsize(p)
                except OSError:
                    pass
    return out


def import_inbox(paths):
    """Moves the inbox photos into the galleries (Auto split). Photos must be in a folder named after
    the insect: inbox/<insect>/photo.jpg. Zips can be anywhere in the inbox."""
    added, insects, loose, counts = {"train": 0, "val": 0}, set(), 0, {}
    g = gallery()
    for p in sorted(paths):
        rel = os.path.relpath(p, INBOX).replace(os.sep, "/").split("/")
        try:
            if p.lower().endswith(".zip"):
                a, ins = import_zip(p, "auto", "")
                for k in a:
                    added[k] += a[k]
                insects.update(ins)
            else:
                cls = safe_name(rel[-2]) if len(rel) > 1 else ""
                if not cls:
                    loose += 1
                    continue   # left in the inbox: we don't know which insect it is
                n = counts.setdefault(cls, sum(len(g[sp].get(cls, [])) for sp in SPLITS))
                a = angle_of(os.path.basename(p), {})
                where = ("val" if a >= VAL_FROM_DEG else "train") if a is not None else ("val" if n % 5 == 4 else "train")
                counts[cls] = n + 1
                dest = os.path.join(DATA, where, cls)
                os.makedirs(dest, exist_ok=True)
                shutil.copyfile(p, free_path(os.path.join(dest, safe_file(os.path.basename(p)) or f"photo_{n:04d}.jpg")))
                added[where] += 1
                insects.add(cls)
            os.remove(p)
        except (OSError, zipfile.BadZipFile) as e:
            print(f"Couldn't add {p}: {e}")
    # tidy up empty insect folders in the inbox
    for dirpath, dirs, files in sorted(os.walk(INBOX), reverse=True):
        if dirpath != INBOX and not os.listdir(dirpath):
            try:
                os.rmdir(dirpath)
            except OSError:
                pass
    return added, sorted(insects), loose


inbox_note = {"text": ""}


def auto_train(prefix=""):
    """New photos arrived (inbox or phone): start training, which then saves the model files by itself."""
    st = load_settings()
    if not st.get("auto_train", True) or trainer.running():
        return
    g = gallery()
    if len(g["train"]) < 2 or not g["val"]:
        inbox_note["text"] = (prefix + " Training starts when there are photos of at least 2 insects.").strip()
        return
    name = safe_name(f"{st['model_name']}_{time.strftime('%Y%m%d_%H%M%S')}")
    trainer.start(name, st["arch"], int(st["epochs"]), int(st["batch"]))
    inbox_note["text"] = f"New photos, so training started: {name}."
    print(f"[auto] Started training {name}", flush=True)


def watch_inbox():
    """Every 3 seconds: when new photos in the inbox have finished copying, add them and start training."""
    last = {}
    while True:
        time.sleep(3)
        try:
            now = inbox_files()
            ready = bool(now) and now == last   # same files and sizes as 3 s ago = copying is done
            last = now
            if not ready or trainer.running():
                continue                        # photos that arrive during training wait for the next run
            added, insects, loose = import_inbox(list(now))
            last = inbox_files()
            got = added["train"] + added["val"]
            note = []
            if got:
                note.append(f"Added {got} new photos ({', '.join(insects)}).")
                print(f"[inbox] Added {added['train']} Training + {added['val']} Validation photos: {', '.join(insects)}", flush=True)
            if loose:
                note.append(f"{loose} photo(s) aren't in an insect folder, so they're still in the inbox.")
            inbox_note["text"] = " ".join(note)
            if not got:
                continue
            auto_train(inbox_note["text"])
        except Exception as e:  # keep watching even if one round goes wrong
            print("[inbox] Problem:", e, flush=True)


def thumb(split, cls, file):
    """A small copy (longest side 240 px) so big galleries load fast. Made once, then kept."""
    src = photo_path(split, cls, file)
    out = os.path.join(THUMBS, split, cls, file + ".jpg")
    if not os.path.exists(out) or os.path.getmtime(out) < os.path.getmtime(src):
        from PIL import Image
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with Image.open(src) as im:
            im = im.convert("RGB")
            im.thumbnail((240, 240))
            im.save(out, "JPEG", quality=80)
    return out


def remove_empty(split, cls):
    d = os.path.join(DATA, split, cls)
    if os.path.isdir(d) and not os.listdir(d):
        os.rmdir(d)


def models_list():
    out = []
    if not os.path.isdir(MODELS):
        return out
    for name in sorted(os.listdir(MODELS)):
        d = os.path.join(MODELS, name)
        if not os.path.isdir(d):
            continue
        info = {}
        try:
            with open(os.path.join(d, "info.json"), encoding="utf-8") as f:
                info = json.load(f)
        except (OSError, ValueError):
            pass
        files = [{"file": f, "size": os.path.getsize(os.path.join(d, f))} for f in sorted(os.listdir(d))]
        out.append({"name": name, "files": files, "best_val_acc": info.get("best_val_acc"),
                    "classes": info.get("classes"), "arch": info.get("arch"), "finished": info.get("finished")})
    return out


class Handler(BaseHTTPRequestHandler):
    server_version = "PyInsectTrainingRig/1"

    def log_message(self, fmt, *args):  # keep the window quiet, except for training messages
        pass

    # ---------- helpers ----------
    def send_json(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if self.path.startswith("/api/import"):   # lets the phone's Data Collector page send photos
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        if self.path.startswith("/api/import"):
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "POST")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def send_file(self, path, download=False, cache=False):
        if not os.path.isfile(path):
            return self.send_json({"error": "not found"}, 404)
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if path.endswith(".js"):
            ctype = "text/javascript"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(os.path.getsize(path)))
        self.send_header("Cache-Control", "max-age=3600" if cache else "no-cache")
        if download:
            self.send_header("Content-Disposition", f"attachment; filename=\"{os.path.basename(path)}\"")
        self.end_headers()
        with open(path, "rb") as f:
            shutil.copyfileobj(f, self.wfile)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def busy(self):
        if trainer.running():
            self.send_json({"error": "Training is running. Wait until it's done (or press Stop) to change the photos."}, 409)
            return True
        return False

    # ---------- GET ----------
    def do_GET(self):
        url = urlparse(self.path)
        parts = [unquote(p) for p in url.path.split("/") if p]
        try:
            if not parts:
                return self.send_file(os.path.join(WEB, "index.html"))
            if parts == ["collect"] and not url.path.endswith("/"):
                self.send_response(301)
                self.send_header("Location", "/collect/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            if parts[:1] == ["collect"] and len(parts) <= 2:
                f = parts[1] if len(parts) == 2 else "index.html"
                if f in ("index.html", "app.js", "style.css", "jszip.min.js"):
                    return self.send_file(os.path.join(COLLECT, f))
            if parts[0] in ("app.js", "style.css") and len(parts) == 1:
                return self.send_file(os.path.join(WEB, parts[0]))
            if parts[0] == "fonts" and len(parts) == 2 and re.fullmatch(r"[A-Za-z0-9_.-]+", parts[1]):
                return self.send_file(os.path.join(WEB, "fonts", parts[1]), cache=True)
            if parts == ["api", "gallery"]:
                return self.send_json(gallery())
            if parts == ["api", "status"]:
                st = trainer.status()
                st["inbox_note"], st["inbox_waiting"] = inbox_note["text"], len(inbox_files())
                st["settings"] = load_settings()
                return self.send_json(st)
            if parts == ["api", "models"]:
                return self.send_json(models_list())
            if parts == ["api", "info"]:
                from trainer import pick_device
                return self.send_json({"archs": ARCHS, "device": pick_device()[1], "val_from_deg": VAL_FROM_DEG})
            if parts[0] == "photo" and len(parts) == 4:
                return self.send_file(photo_path(*parts[1:]), cache=True)
            if parts[0] == "thumb" and len(parts) == 4:
                return self.send_file(thumb(*parts[1:]), cache=True)
            if parts[0] == "models" and len(parts) == 3 and safe_name(parts[1]) == parts[1] and "/" not in parts[2] and not parts[2].startswith("."):
                return self.send_file(os.path.join(MODELS, parts[1], parts[2]), download=True)
            return self.send_json({"error": "not found"}, 404)
        except ValueError:
            return self.send_json({"error": "bad request"}, 400)

    # ---------- POST ----------
    def do_POST(self):
        url = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        try:
            if url.path == "/api/import":   # body = a .zip or one photo
                if self.busy():
                    return
                split = q.get("split", "auto")
                if split not in ("auto", "train", "val"):
                    return self.send_json({"error": "bad split"}, 400)
                filename = os.path.basename(q.get("filename", "upload"))
                n = int(self.headers.get("Content-Length") or 0)
                with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(filename)[1]) as tmp:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(left, 1 << 20))
                        if not chunk:
                            break
                        tmp.write(chunk)
                        left -= len(chunk)
                try:
                    if zipfile.is_zipfile(tmp.name):
                        stem = os.path.splitext(filename)[0]   # the zip's own name, if nothing better
                        added, insects = import_zip(tmp.name, split, q.get("name", ""), stem)
                    else:
                        cls = safe_name(q.get("name", ""))
                        f = safe_file(filename)
                        if not cls or not f:
                            return self.send_json({"error": "Type the insect's name for single photos."}, 400)
                        g = gallery()   # Auto: every 5th photo of an insect goes to Validation
                        where = split if split != "auto" else ("val" if (len(g["train"].get(cls, [])) + len(g["val"].get(cls, []))) % 5 == 4 else "train")
                        dest = os.path.join(DATA, where, cls)
                        os.makedirs(dest, exist_ok=True)
                        shutil.copyfile(tmp.name, free_path(os.path.join(dest, f)))
                        added, insects = {"train": int(where == "train"), "val": int(where == "val")}, [cls]
                finally:
                    os.unlink(tmp.name)
                self.send_json({"added": added, "insects": insects})
                if added.get("train", 0) + added.get("val", 0):
                    threading.Thread(target=auto_train, args=("Photos arrived from the phone.",), daemon=True).start()
                return

            if url.path == "/api/photos/delete":   # {photos: [{split, cls, file}]}
                if self.busy():
                    return
                done = 0
                for p in self.body_json().get("photos", []):
                    path = photo_path(p.get("split"), p.get("cls"), p.get("file"))
                    if os.path.isfile(path):
                        os.remove(path)
                        done += 1
                    remove_empty(p.get("split"), p.get("cls"))
                return self.send_json({"deleted": done})

            if url.path == "/api/photos/move":   # {photos: [...]} to the other gallery
                if self.busy():
                    return
                done = 0
                for p in self.body_json().get("photos", []):
                    path = photo_path(p.get("split"), p.get("cls"), p.get("file"))
                    other = "val" if p["split"] == "train" else "train"
                    if os.path.isfile(path):
                        dest = os.path.join(DATA, other, p["cls"])
                        os.makedirs(dest, exist_ok=True)
                        shutil.move(path, free_path(os.path.join(dest, p["file"])))
                        done += 1
                    remove_empty(p["split"], p["cls"])
                return self.send_json({"moved": done})

            if url.path == "/api/insect/delete":   # {cls} from both galleries
                if self.busy():
                    return
                cls = safe_name(self.body_json().get("cls", ""))
                for split in SPLITS:
                    d = os.path.join(DATA, split, cls)
                    if cls and os.path.isdir(d):
                        shutil.rmtree(d)
                return self.send_json({"ok": True})

            if url.path == "/api/train":   # {name, arch, epochs, batch}
                b = self.body_json()
                name = safe_name(b.get("name", ""))
                if not name:
                    return self.send_json({"error": "Type a model name first."}, 400)
                epochs = max(1, min(int(b.get("epochs") or 30), 1000))
                batch = max(1, min(int(b.get("batch") or 16), 256))
                if os.path.isdir(os.path.join(MODELS, name)) and not b.get("overwrite"):
                    return self.send_json({"error": "exists", "name": name}, 409)
                trainer.start(name, b.get("arch", "efficientnet_b0"), epochs, batch)
                return self.send_json({"ok": True, "name": name})

            if url.path == "/api/stop":
                trainer.stop()
                return self.send_json({"ok": True})

            return self.send_json({"error": "not found"}, 404)
        except (ValueError, KeyError, RuntimeError) as e:
            return self.send_json({"error": str(e)}, 400)
        except zipfile.BadZipFile:
            return self.send_json({"error": "That zip file is broken."}, 400)


def lan_addresses():
    try:
        return sorted({a[4][0] for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)} - {"127.0.0.1"})
    except OSError:
        return []


def main():
    ap = argparse.ArgumentParser(description="PyInsect Training Rig (offline)")
    ap.add_argument("--port", type=int, default=8100)
    ap.add_argument("--lan", action="store_true", help="let other computers on this network open the page")
    args = ap.parse_args()
    for split in SPLITS:
        os.makedirs(os.path.join(DATA, split), exist_ok=True)
    os.makedirs(MODELS, exist_ok=True)
    os.makedirs(INBOX, exist_ok=True)
    load_settings()
    threading.Thread(target=watch_inbox, daemon=True).start()
    host = "0.0.0.0" if args.lan else "127.0.0.1"
    httpd = ThreadingHTTPServer((host, args.port), Handler)
    print("PyInsect Training Rig is running. Leave this window open. Press Ctrl+C to stop.")
    print(f"  On this computer: http://localhost:{args.port}")
    if args.lan:
        for a in lan_addresses():
            print(f"  From another computer on this network: http://{a}:{args.port}")
    print(f"  Put new photos in: {os.path.join(INBOX, '<insect name>')}  (or the rig's .zip files right in the inbox)")
    print(f"  Settings: {SETTINGS}")
    print(f"  Photos: {DATA}")
    print(f"  Models: {MODELS}")
    sys.stdout.flush()
    webbrowser.open(f"http://localhost:{args.port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("Stopped.")

if __name__ == "__main__":
    main()
